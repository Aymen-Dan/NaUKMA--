import java.io.IOException;

import my.utils.DataInput;
import my.utils.StudentsGrades;
import utils.DataInput1;
import utils.HW1;

public class HW1_tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int numOfStudents = 0;
		int[] gList;
		String[] nList;

		System.out.println("Enter the number of students please: ");
		numOfStudents = DataInput1.getInt();
		gList = new int[numOfStudents];
		nList = new String[numOfStudents];

		System.out.println("Enter the grades please: ");
		for (int i = 0; i < numOfStudents; i++) {
			gList[i] = DataInput1.getInt();
		}
		System.out.println("Enter the student's name please: " );
		for (int i = 0; i < numOfStudents; i++) {
			try {
				nList[i] = DataInput1.getString();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

			HW1 sg = new HW1(numOfStudents);

			sg.setGrades(gList, nList);

			System.out.println(sg.toStringGrades());
			System.out.println(sg.toStringNames());

		

		
		
		 
		 /* for (int i = 0; i < maxLength; i++) { numOfStudents[i] =
		 * DataInput1.getString("Введіть оцінку " + (i + 1) +
		 * "-го студента (-1 означає кінець введення): "); } for (int i = 0; i <
		 * numOfStudents.length; i++) {
		 * System.out.print("Введіть оцінку студента " + (i + 1) + ": ");
		 * 
		 * System.out.print("Enter Name of Student " + (i + 1) + ": ");
		 */

	}

	// System.out.print("This program prints out the text of your .txt file");
	// String originalStr = "";
	// try {
	// FileReader reader = new FileReader(readLine("What .txt?"));
	// int c;
	// while ((c = reader.read()) != -1) {
	// originalStr += (char) c;
	// }
	// String k = readLine("What word are you searching for?");
	// System.out.println(originalStr.split(k).length - 1);
	// } catch (IOException e) {
	// TODO Auto-generated catch block
	// e.printStackTrace();
	// }
}
