package utils;

import java.io.FileReader;

import java.io.IOException;

public class HW1 {

	private int[] Grades;
	private String[] Names;
	private String name;
	private int grade;

	public HW1() {
		Grades = new int[10];
	}

	public HW1(int size) {
		Grades = new int[size];
		Names = new String[size];
	}

	public HW1(HW1 sg, int grade) {
		int l = sg.Grades.length;

		Grades = new int[l];
		Names = new String[l];

		for (int i = 0; i < l; i++) {

			Grades[i] = sg.Grades[i];
			Names[i] = sg.Names[i];
		}
	}

	public String getName() {
		return name;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrades(int[] marks, String[] students) {

		int l = marks.length;

		Grades = new int[l];
		Names = new String[l];

		// a loop to have the program take inputs until all the students get
		// their marks
		for (int i = 0; i < l; i++) {

			// a check to only remember the marks that are proper(in the range
			// from 0 to 100)
			if (marks[i] >= 0 && marks[i] <= 100) {
				Grades[i] = marks[i];
			}
			Names[i] = students[i];
		}
	}

	public int[] getGrades() {
		int l = Grades.length;
		int[] gradesCopy = new int[l];
		for (int i = 0; i < l; i++) {
			gradesCopy[i] = Grades[i];
		}
		return gradesCopy;
	}

	public String[] getNames() {
		int l = Names.length;
		String[] namesCopy = new String[l];
		for (int i = 0; i < l; i++) {
			namesCopy[i] = Names[i];
		}
		return namesCopy;
	}

	public String toStringGrades() {
		String res = new String();
		for (int i = 0; i < Grades.length - 1; i++) {
			res += Grades[i] + ", ";
		}
		res += Grades[Grades.length - 1];
		return res;
	}
	
	public String toStringNames() {
		String res = new String();
		for (int i = 0; i < Names.length - 1; i++) {
			res += Names[i] + ", ";
		}
		res += Names[Names.length - 1];
		return res;
	}
	
}
